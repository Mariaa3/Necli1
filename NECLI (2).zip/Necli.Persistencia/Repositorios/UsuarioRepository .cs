﻿using System.Data.SqlClient;
using Necli.Entidades.Entities;
using Necli.Persistencia.Interfaces;

namespace Necli.Persistencia.Repositorios
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private readonly string _connectionString;

        public UsuarioRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public Usuario? Consultar(string identificacion)
        {
            using var conn = new SqlConnection(_connectionString);
            var query = "SELECT * FROM Usuarios WHERE Identificacion = @Identificacion";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Identificacion", identificacion);

            conn.Open();
            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return LeerUsuario(reader);
            }

            return null;
        }

        public Usuario? ConsultarPorEmail(string email)
        {
            using var conn = new SqlConnection(_connectionString);
            var query = "SELECT * FROM Usuarios WHERE Email = @Email";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);

            conn.Open();
            using var reader = cmd.ExecuteReader();
            return reader.Read() ? LeerUsuario(reader) : null;
        }

        public bool ExisteEmail(string email)
        {
            using var conn = new SqlConnection(_connectionString);
            var query = "SELECT COUNT(1) FROM Usuarios WHERE Email = @Email";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);

            conn.Open();
            return (int)cmd.ExecuteScalar() > 0;
        }

        public bool ExisteTelefono(string numeroTelefono)
        {
            using var conn = new SqlConnection(_connectionString);
            var query = "SELECT COUNT(1) FROM Usuarios WHERE NumeroTelefono = @NumeroTelefono";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@NumeroTelefono", numeroTelefono);

            conn.Open();
            return (int)cmd.ExecuteScalar() > 0;
        }

        public bool Actualizar(Usuario usuario)
        {
            using var conn = new SqlConnection(_connectionString);
            var query = @"UPDATE Usuarios 
                          SET Nombres = @Nombres, Apellidos = @Apellidos, Email = @Email, ContraseñaHash = @Hash 
                          WHERE Identificacion = @Id";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Nombres", usuario.Nombres);
            cmd.Parameters.AddWithValue("@Apellidos", usuario.Apellidos);
            cmd.Parameters.AddWithValue("@Email", usuario.Email);
            cmd.Parameters.AddWithValue("@Hash", usuario.ContraseñaHash);
            cmd.Parameters.AddWithValue("@Id", usuario.Identificacion);

            conn.Open();
            return cmd.ExecuteNonQuery() > 0;
        }

        private Usuario LeerUsuario(SqlDataReader reader)
        {
            return new Usuario
            {
                Identificacion = reader["Identificacion"].ToString()!,
                Tipo = reader["Tipo"].ToString()!,
                Nombres = reader["Nombres"].ToString()!,
                Apellidos = reader["Apellidos"].ToString()!,
                Email = reader["Email"].ToString()!,
                NumeroTelefono = reader["NumeroTelefono"].ToString()!,
                ContraseñaHash = reader["ContraseñaHash"].ToString()!,
                FechaCreacion = Convert.ToDateTime(reader["FechaCreacion"])
            };
        }

        public IEnumerable<object> ObtenerTodos()
        {
            throw new NotImplementedException();
        }

        public Usuario ConsultarPorEmail(object email)
        {
            throw new NotImplementedException();
        }
    }
}
