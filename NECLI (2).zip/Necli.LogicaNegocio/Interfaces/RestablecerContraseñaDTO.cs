﻿namespace Necli.LogicaNegocio.Interfaces
{
    public class RestablecerContraseñaDTO
    {
    }
}