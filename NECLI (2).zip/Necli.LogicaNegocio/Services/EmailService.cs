﻿
namespace Necli.LogicaNegocio.Services
{
    internal class EmailService
    {
        internal async Task EnviarCorreoConAdjunto(object email, string v, string cuerpo, object rutaPdf)
        {
            throw new NotImplementedException();
        }
    }
}