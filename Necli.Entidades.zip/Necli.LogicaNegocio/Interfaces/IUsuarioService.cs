﻿using Necli.Aplicacion.DTOs;
using Necli.LogicaNegocio.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Necli.LogicaNegocio.Interfaces
{
    public interface IUsuarioService
    {
        UsuarioRespuestaDTO? Consultar(string identificacion);
        bool Actualizar(string identificacion, UsuarioActualizarDTO dto);
        bool RestablecerContraseña(RestablecerContraseñaDTO dto);
    }
}
