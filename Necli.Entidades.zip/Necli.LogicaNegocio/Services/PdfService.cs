﻿using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using Necli.Entidades.Entities;
using iText.Kernel.Font;
using iText.IO.Font.Constants;

namespace Necli.LogicaNegocio.Services
{
    public class PdfService
    {
        public string GenerarResumenMensual(List<Transaccion> transacciones, Usuario usuario)
        {
            var ruta = Path.Combine(Path.GetTempPath(), $"Resumen_{usuario.Identificacion}_{DateTime.Now:yyyyMMddHHmmss}.pdf");

            using (var writer = new PdfWriter(ruta))
            using (var pdf = new PdfDocument(writer))
            using (var document = new Document(pdf))
            {
                var boldFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);

                var titulo = new Paragraph($"Resumen de Movimientos - {usuario.Nombres} {usuario.Apellidos}")
                    .SetFont(boldFont)
                    .SetFontSize(14)
                    .SetTextAlignment(TextAlignment.CENTER);

                document.Add(titulo);
                document.Add(new Paragraph($"Documento: {usuario.Identificacion}").SetFontSize(10));
                document.Add(new Paragraph($"Fecha: {DateTime.Now:dd/MM/yyyy}").SetFontSize(10));
                document.Add(new Paragraph(" "));

                var tabla = new Table(5).UseAllAvailableWidth();
                tabla.AddHeaderCell("Fecha");
                tabla.AddHeaderCell("Origen");
                tabla.AddHeaderCell("Destino");
                tabla.AddHeaderCell("Monto");
                tabla.AddHeaderCell("Tipo");

                foreach (var t in transacciones)
                {
                    tabla.AddCell(t.Fecha.ToString("dd/MM/yyyy"));
                    tabla.AddCell(t.CuentaOrigenId.ToString());
                    tabla.AddCell(t.CuentaDestinoId.ToString());
                    tabla.AddCell(t.Monto.ToString("C"));
                    tabla.AddCell(t.Tipo);
                }

                document.Add(tabla);
            }

            return ruta;
        }
    }
}
