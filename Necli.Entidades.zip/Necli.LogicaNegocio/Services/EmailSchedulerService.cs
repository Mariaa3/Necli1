﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Necli.Persistencia.Repositorios;
using Necli.Entidades.Entities;

namespace Necli.LogicaNegocio.Services
{
    public class EmailSchedulerService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;

        public EmailSchedulerService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var hoy = DateTime.Now;

                if (hoy.Day == 1)
                {
                    using var scope = _serviceProvider.CreateScope();

                    var transaccionRepo = scope.ServiceProvider.GetRequiredService<TransaccionRepositorio>();
                    var usuarioRepo = scope.ServiceProvider.GetRequiredService<UsuarioRepositorio>();
                    var cuentaRepo = scope.ServiceProvider.GetRequiredService<CuentaRepository>();
                    var pdfService = scope.ServiceProvider.GetRequiredService<PdfService>();
                    var emailService = scope.ServiceProvider.GetRequiredService<EmailService>();

                    var transacciones = transaccionRepo.ObtenerTodas();
                    var usuarios = usuarioRepo.ObtenerTodos();
                    var cuentas = cuentaRepo.ObtenerTodas();

                    var mesAnterior = hoy.AddMonths(-1);
                    var inicio = new DateTime(mesAnterior.Year, mesAnterior.Month, 1);
                    var fin = inicio.AddMonths(1).AddDays(-1);

                    foreach (var usuario in usuarios)
                    {
                        var cuentasUsuario = cuentas
                            .Where(c => c.UsuarioId == usuario.Identificacion)
                            .Select(c => c.Numero)
                            .ToList();

                        var transaccionesUsuario = transacciones
                            .Where(t => cuentasUsuario.Contains(t.CuentaOrigenId) || cuentasUsuario.Contains(t.CuentaDestinoId))
                            .Where(t => t.Fecha >= inicio && t.Fecha <= fin)
                            .ToList();

                        if (transaccionesUsuario.Any())
                        {
                            var rutaPdf = pdfService.GenerarResumenMensual(transaccionesUsuario, usuario);

                            var cuerpo = $"<p>Adjunto se encuentra su resumen de movimientos de {inicio:MMMM yyyy}.</p>";

                            await emailService.EnviarCorreoConAdjunto(
                                usuario.Email,
                                "Resumen mensual de movimientos NECLI",
                                cuerpo,
                                rutaPdf
                            );
                        }
                    }
                }

                await Task.Delay(TimeSpan.FromHours(24), stoppingToken);
            }
        }
    }
}
