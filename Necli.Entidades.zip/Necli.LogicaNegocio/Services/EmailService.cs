﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;

namespace Necli.LogicaNegocio.Services
{
    public class EmailService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;

        public EmailService(IConfiguration configuration)
        {
            _httpClient = new HttpClient();
            _apiKey = configuration["Resend:ApiKey"]!;
        }

        public async Task EnviarCorreo(string destinatario, string asunto, string cuerpoHtml)
        {
            var request = new
            {
                from = "Necli <onboarding@resend.dev>",
                to = new[] { destinatario },
                subject = asunto,
                html = cuerpoHtml
            };

            var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _apiKey);

            var response = await _httpClient.PostAsync("https://api.resend.com/emails", content);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"Error al enviar correo: {error}");
            }
        }

        public async Task EnviarCorreoConAdjunto(string destinatario, string asunto, string cuerpoHtml, string rutaArchivoPdf)
        {
            var fileBytes = File.ReadAllBytes(rutaArchivoPdf);
            var base64File = Convert.ToBase64String(fileBytes);

            var content = new
            {
                from = "Necli <onboarding@resend.dev>",
                to = new[] { destinatario },
                subject = asunto,
                html = cuerpoHtml,
                attachments = new[]
                {
                    new
                    {
                        filename = Path.GetFileName(rutaArchivoPdf),
                        content = base64File,
                        type = "application/pdf"
                    }
                }
            };

            var json = JsonSerializer.Serialize(content);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _apiKey);
            var response = await _httpClient.PostAsync("https://api.resend.com/emails", httpContent);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"Error al enviar correo con adjunto: {error}");
            }
        }
    }
}
