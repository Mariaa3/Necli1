﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Necli.Aplicacion.DTOs
{
    public class CuentaCrearDTO
    {
        public UsuarioCrearDTO Usuario { get; set; }
    }
}
