﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Necli.Aplicacion.DTOs;
using Necli.LogicaNegocio.Interfaces;

namespace Necli.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CuentaController : ControllerBase
    {
        private readonly ICuentaService _cuentaService;

        public CuentaController(ICuentaService cuentaService)
        {
            _cuentaService = cuentaService;
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult CrearCuenta([FromBody] CuentaCrearDTO dto)
        {
            try
            {
                var resultado = _cuentaService.CrearCuenta(dto);
                if (!resultado)
                    return StatusCode(500, "No se pudo crear la cuenta.");
                return StatusCode(201, "Cuenta creada exitosamente.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{numero}")]
        [Authorize]
        public IActionResult Consultar(int numero)
        {
            var cuenta = _cuentaService.ConsultarCuenta(numero);
            if (cuenta == null)
                return NotFound("Cuenta no encontrada.");
            return Ok(cuenta);
        }

        [HttpDelete("{numero}")]
        [Authorize]
        public IActionResult Eliminar(int numero)
        {
            try
            {
                var eliminado = _cuentaService.EliminarCuenta(numero);
                return eliminado ? Ok("Cuenta eliminada correctamente.") : NotFound("Cuenta no encontrada.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
