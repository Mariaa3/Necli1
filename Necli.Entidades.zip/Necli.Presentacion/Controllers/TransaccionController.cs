﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Necli.Aplicacion.DTOs;
using Necli.LogicaNegocio.Interfaces;
using System.Security.Claims;

namespace Necli.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransaccionController : ControllerBase
    {
        private readonly ITransaccionService _transaccionService;

        public TransaccionController(ITransaccionService transaccionService)
        {
            _transaccionService = transaccionService;
        }

        [HttpPost]
        [Authorize]
        public IActionResult Realizar([FromBody] TransaccionCrearDTO dto)
        {
            try
            {
                var cuentaOrigenId = ObtenerCuentaIdDesdeToken();
                var resultado = _transaccionService.RealizarTransaccion(cuentaOrigenId, dto);
                return resultado ? Ok("Transacción realizada.") : BadRequest("Error al realizar transacción.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Authorize]
        public IActionResult Consultar([FromQuery] TransaccionConsultaDTO filtro)
        {
            var cuentaOrigenId = ObtenerCuentaIdDesdeToken();
            var lista = _transaccionService.ConsultarTransacciones(filtro, cuentaOrigenId);
            return Ok(lista);
        }

        private int ObtenerCuentaIdDesdeToken()
        {
            var claim = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
            if (claim == null)
                throw new UnauthorizedAccessException("No se encontró el identificador del usuario.");
            return int.Parse(claim.Value);
        }
    }
}
