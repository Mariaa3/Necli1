﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Necli.Aplicacion.DTOs;
using Necli.LogicaNegocio.Interfaces;

namespace Necli.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioService _usuarioService;

        public UsuarioController(IUsuarioService usuarioService)
        {
            _usuarioService = usuarioService;
        }

        [HttpGet("{identificacion}")]
        [Authorize]
        public IActionResult Consultar(string identificacion)
        {
            var usuario = _usuarioService.Consultar(identificacion);
            if (usuario == null)
                return NotFound("Usuario no encontrado.");
            return Ok(usuario);
        }

        [HttpPut("{identificacion}")]
        [Authorize]
        public IActionResult Actualizar(string identificacion, [FromBody] UsuarioActualizarDTO dto)
        {
            try
            {
                var actualizado = _usuarioService.Actualizar(identificacion, dto);
                return actualizado ? Ok("Usuario actualizado correctamente.") : NotFound("Usuario no encontrado.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("restablecer-clave")]
        [AllowAnonymous]
        public IActionResult RestablecerClave([FromBody] RestablecerContraseñaDTO dto)
        {
            try
            {
                var resultado = _usuarioService.RestablecerContraseña(dto);
                return resultado ? Ok("Contraseña restablecida y enviada por correo.") : NotFound("Usuario no encontrado.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
