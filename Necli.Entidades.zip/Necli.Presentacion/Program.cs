using Necli.Persistencia.Repositorios;
using Necli.LogicaNegocio.Services;
using Necli.Persistencia.Interfaces;
using Necli.LogicaNegocio.Interfaces;
using Microsoft.OpenApi.Models;
using AutoMapper;

var builder = WebApplication.CreateBuilder(args);

// Add controllers
builder.Services.AddControllers();

// Swagger (incluye configuraci�n opcional para JWT m�s adelante)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Necli API", Version = "v1" });
});

// Configuraci�n de AutoMapper
builder.Services.AddAutoMapper(typeof(UsuarioProfile).Assembly);

// Repositorios 
builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>(provider =>
{
    var config = provider.GetRequiredService<IConfiguration>();
    return new UsuarioRepository(config.GetConnectionString("DefaultConnection")!);
});

builder.Services.AddScoped<ICuentaRepository, CuentaRepository>(provider =>
{
    var config = provider.GetRequiredService<IConfiguration>();
    return new CuentaRepository(config.GetConnectionString("DefaultConnection")!);
});

builder.Services.AddScoped<ITransaccionRepository, TransaccionRepository>(provider =>
{
    var config = provider.GetRequiredService<IConfiguration>();
    return new TransaccionRepository(config.GetConnectionString("DefaultConnection")!);
});

// Servicios de l�gica de negocio
builder.Services.AddScoped<IUsuarioService, UsuarioService>();
builder.Services.AddScoped<ICuentaService, CuentaService>();
builder.Services.AddScoped<ITransaccionService, TransaccionService>();


builder.Services.AddScoped<PdfService>();
builder.Services.AddScoped<EmailService>();
builder.Services.AddHostedService<EmailSchedulerService>();

var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();



app.UseAuthorization();

app.MapControllers();

app.Run();
